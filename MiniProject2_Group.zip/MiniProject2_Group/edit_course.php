<?php
session_start();
include 'db.php';
include 'header.php';

// Pastikan hanya Admin boleh akses
if ($_SESSION['role'] != 'Admin') {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];
$course_code = "";
$course_name = "";

// 1. Ambil data asal dari database
$stmt = $conn->prepare("SELECT course_code, course_name FROM courses WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $course_code = $row['course_code'];
    $course_name = $row['course_name'];
}

// 2. Proses kemaskini apabila butang Update ditekan
if (isset($_POST['update'])) {
    $new_code = $_POST['course_code'];
    $new_name = $_POST['course_name'];

    $update_stmt = $conn->prepare("UPDATE courses SET course_code = ?, course_name = ? WHERE id = ?");
    $update_stmt->bind_param("ssi", $new_code, $new_name, $id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Kursus berjaya dikemaskini!'); window.location='view_courses.php';</script>";
    } else {
        echo "Ralat: " . $conn->error;
    }
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card card-custom p-4 shadow-sm">
                <h3 class="text-center mb-4" style="color: #A10B9F;">Edit Kursus</h3>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Kod Kursus</label>
                        <input type="text" name="course_code" class="form-control" value="<?php echo $course_code; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Kursus</label>
                        <input type="text" name="course_name" class="form-control" value="<?php echo $course_name; ?>" required>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="update" class="btn btn-custom w-100">Simpan Perubahan</button>
                        <a href="view_courses.php" class="btn btn-secondary w-100">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>