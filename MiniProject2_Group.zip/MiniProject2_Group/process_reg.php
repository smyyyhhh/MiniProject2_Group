<?php
include 'db.php';

if (isset($_POST['save'])) {
    $user = $_POST['username'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure coding [cite: 94]
    $role = $_POST['role']; // Ambil data role dari borang

    // Kemaskini query untuk masukkan 'role'
    $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $user, $pass, $role);

    if ($stmt->execute()) {
        echo "<script>alert('Pendaftaran sebagai " . $role . " Berjaya!'); window.location='index.php';</script>";
    } else {
        echo "Ralat: " . $conn->error;
    }
    
    $stmt->close();
    $conn->close();
}
?>