<?php
session_start();
include 'db.php';
include 'header.php';

// Hanya Admin boleh akses [cite: 94, 98]
if ($_SESSION['role'] != 'Admin') {
    header("Location: dashboard.php");
    exit();
}

// Ambil semua kursus dari database [cite: 123]
$sql = "SELECT * FROM courses";
$result = $conn->query($sql);
?>

<div class="container mt-4">
    <div class="card card-custom p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>Senarai Kursus</h3>
            <a href="add_course.php" class="btn btn-custom">Tambah Kursus Baru</a>
        </div>
        
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Kod Kursus</th>
                    <th>Nama Kursus</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['course_code']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                    <td>
                        <a href="edit_course.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        
                        <a href="delete_course.php?id=<?php echo $row['id']; ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Adakah anda pasti mahu memadam kursus ini?')">Padam</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
    </div>
</div>

<?php include 'footer.php'; ?>