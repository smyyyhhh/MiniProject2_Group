<?php
session_start();
include 'db.php';
include 'header.php';

if ($_SESSION['role'] != 'Student') {
    header("Location: dashboard.php");
    exit();
}
?>

<div class="container mt-4">
    <div class="card card-custom p-4">
        <h3 class="mb-4">Daftar Kursus</h3>
        
        <div class="mb-3">
            <input type="text" id="search_text" class="form-control" placeholder="Cari kod atau nama kursus...">
        </div>

        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Kod</th>
                    <th>Nama Kursus</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody id="result_table">
                </tbody>
        </table>
        <a href="dashboard.php" class="btn btn-secondary mt-3">Kembali</a>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    // Fungsi untuk ambil data
    function load_data(query) {
        $.ajax({
            url: "fetch_course.php",
            method: "POST",
            data: {query: query},
            success: function(data) {
                $('#result_table').html(data);
            }
        });
    }

    // Panggil fungsi masa mula-mula buka page
    load_data('');

    // Panggil fungsi bila user menaip
    $('#search_text').keyup(function(){
        var search = $(this).val();
        load_data(search);
    });
});
</script>