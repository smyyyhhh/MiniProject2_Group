<?php
$conn = new mysqli("localhost", "root", "", "pcrs_db2");

if ($conn->connect_error) {
    die("Sambungan gagal: " . $conn->connect_error);
}
?>