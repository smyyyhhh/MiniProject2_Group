<?php
session_start();
include 'db.php';
include 'header.php';

// 1. Pastikan user dah login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];
$role = $_SESSION['role'];
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Selamat Datang, <span style="color: #A10B9F;"><?php echo $username; ?></span>!</h2>
        <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>

    <div class="row">
        <div class="col-md-4">
            <?php if ($role == 'Admin'): ?>
                <div class="card card-custom p-3 text-center mb-3 shadow-sm">
                    <h4 style="color: #A10B9F;">Menu Admin</h4>
                    <hr>
                    <a href="add_course.php" class="btn btn-custom w-100 mb-2">Tambah Kursus</a>
                    <a href="view_courses.php" class="btn btn-outline-dark w-100 mb-2">Urus Senarai Kursus</a>
                    <a href="view_registrations.php" class="btn btn-outline-dark w-100">Lihat Pendaftaran Pelajar</a>
                </div>
            <?php else: ?>
                <div class="card card-custom p-3 text-center mb-3 shadow-sm">
                    <h4 style="color: #A10B9F;">Menu Pelajar</h4>
                    <hr>
                    <a href="register_course.php" class="btn btn-custom w-100 mb-2">Daftar Kursus</a>
                    <a href="my_courses.php" class="btn btn-outline-dark w-100">Kursus Saya</a>
                </div>
            <?php endif; ?>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm p-4" style="border-radius: 15px; min-height: 200px;">
                <h5 class="fw-bold">Sistem Maklumat Kursus Politeknik (PCRS)</h5>
                <p class="text-muted mt-3">
                    Selamat datang ke sistem pengurusan kursus. Sila gunakan menu di sebelah kiri untuk mula menguruskan maklumat anda mengikut peranan akaun anda.
                </p>
                <hr>
                <small class="text-secondary italic">Status Log Masuk: <strong><?php echo $role; ?></strong></small>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>