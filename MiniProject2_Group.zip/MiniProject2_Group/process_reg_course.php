<?php
session_start();
include 'db.php';

if (isset($_GET['course_id'])) {
    $user_id = $_SESSION['user_id'];
    $course_id = $_GET['course_id'];

    // Semak jika pelajar sudah daftar kursus yang sama (Validation)
    $check = $conn->prepare("SELECT id FROM registrations WHERE user_id = ? AND course_id = ?");
    $check->bind_param("ii", $user_id, $course_id);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {
        echo "<script>alert('You have already registered for this course!'); window.location='register_course.php';</script>";
    } else {
        // Simpan pendaftaran baru
        $sql = "INSERT INTO registrations (user_id, course_id) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $user_id, $course_id);

        if ($stmt->execute()) {
            echo "<script>alert('Registration Successful!'); window.location='my_courses.php';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>