<?php
session_start();
include 'db.php';
include 'header.php';

$user_id = $_SESSION['user_id'];

// Join table untuk dapatkan nama kursus yang didaftar oleh pelajar ini
$sql = "SELECT r.id as reg_id, c.course_code, c.course_name 
        FROM registrations r 
        JOIN courses c ON r.course_id = c.id 
        WHERE r.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container mt-4">
    <div class="card card-custom p-4">
        <h3 class="mb-4">My Registered Courses</h3>
        <table class="table table-bordered">
            <thead class="bg-light">
                <tr>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['course_code']; ?></td>
                        <td><?php echo $row['course_name']; ?></td>
                        <td>
                            <a href="drop_course.php?id=<?php echo $row['reg_id']; ?>" 
                               class="btn btn-danger btn-sm">Drop</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="3" class="text-center">No courses registered yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn btn-secondary mt-3">Back</a>
    </div>
</div>