<?php
include 'db.php';

$output = '';
if(isset($_POST["query"])) {
    $search = "%" . $_POST["query"] . "%";
    $sql = "SELECT * FROM courses WHERE course_code LIKE ? OR course_name LIKE ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $search, $search);
} else {
    $sql = "SELECT * FROM courses";
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $output .= '
        <tr>
            <td>'.$row["course_code"].'</td>
            <td>'.$row["course_name"].'</td>
            <td>
                <a href="process_reg_course.php?course_id='.$row["id"].'" 
                   class="btn btn-custom btn-sm" 
                   onclick="return confirm(\'Sahkan pendaftaran?\')">Daftar</a>
            </td>
        </tr>';
    }
} else {
    $output .= '<tr><td colspan="3" class="text-center">Kursus tidak dijumpai</td></tr>';
}
echo $output;
?>