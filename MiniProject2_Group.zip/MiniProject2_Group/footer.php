<footer class="mt-5 pb-3 text-center text-muted">
        <hr>
        <p>&copy; 2026 PCRS - Politeknik Sultan Idris Shah</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>