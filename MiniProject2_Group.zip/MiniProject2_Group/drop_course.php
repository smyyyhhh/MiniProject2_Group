<?php
session_start();
include 'db.php';

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Gunakan Prepared Statement untuk keselamatan [cite: 122]
    $sql = "DELETE FROM registrations WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if($stmt->execute()) {
        echo "<script>alert('Kursus berjaya digugurkan!'); window.location='my_courses.php';</script>";
    } else {
        echo "Ralat: " . $conn->error;
    }
}
?>