<?php
session_start();
include 'db.php';

if(isset($_GET['id']) && $_SESSION['role'] == 'Admin') {
    $id = $_GET['id'];
    
    // Gunakan prepared statement [cite: 122]
    $stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if($stmt->execute()) {
        echo "<script>alert('Kursus berjaya dipadam!'); window.location='view_courses.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>