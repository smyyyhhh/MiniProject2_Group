<?php
session_start();
include 'db.php';
include 'header.php';

// Pastikan hanya Admin boleh tengok senarai pendaftaran
if ($_SESSION['role'] != 'Admin') {
    header("Location: dashboard.php");
    exit();
}

// Query untuk dapatkan maklumat Student dan Kursus yang didaftar (JOIN 3 table)
$sql = "SELECT u.username, c.course_code, c.course_name, r.reg_date 
        FROM registrations r
        JOIN users u ON r.user_id = u.id
        JOIN courses c ON r.course_id = c.id
        ORDER BY r.reg_date DESC";
$result = $conn->query($sql);
?>

<div class="container mt-4">
    <div class="card card-custom p-4">
        <h3 class="mb-4">All Student Registrations</h3>
        <table class="table table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>Student Name</th>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Date Registered</th>
                </tr>
            </thead>
            <tbody>
                <?php if($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['course_code']; ?></td>
                        <td><?php echo $row['course_name']; ?></td>
                        <td><?php echo date('d-m-Y H:i', strtotime($row['reg_date'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="4" class="text-center">No registrations found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="mt-3">
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>