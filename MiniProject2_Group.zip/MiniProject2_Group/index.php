<?php include 'header.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card card-custom p-4">
                <h3 class="text-center mb-4">Login PCRS</h3>
                <form action="process_login.php" method="POST">
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-custom w-100 p-2">Login</button>
                    <p class="text-center mt-3 small">New student? <a href="register.php">Register here</a></p>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>