<?php include 'header.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card card-custom p-4">
                <h3 class="text-center mb-4">Register</h3>
                <form action="process_reg.php" method="POST">
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Enter username" required>
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                    </div>
                    <div class="mb-4">
                        <label>Register As:</label>
                        <select name="role" class="form-select" required>
                            <option value="" disabled selected>Select Role</option>
                            <option value="Student">Student</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </div>
                    <button type="submit" name="save" class="btn btn-custom w-100 p-2">Register</button>
                    <p class="text-center mt-3 small">Already have an account? <a href="index.php">Login here</a></p>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>