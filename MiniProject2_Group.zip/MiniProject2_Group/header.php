<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PCRS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fcf8ff; }
        .bg-purple { background-color: #A10B9F !important; }
        .btn-custom { background-color: #A10B9F; color: white; border-radius: 8px; }
        .btn-custom:hover { background-color: #8a0988; color: white; }
        .card-custom { border: none; border-top: 5px solid #A10B9F; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-purple mb-4">
    <div class="container">
        <span class="navbar-brand">PCRS POLYTECHNIC</span>
    </div>
</nav>