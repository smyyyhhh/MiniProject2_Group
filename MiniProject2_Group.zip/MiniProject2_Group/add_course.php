<?php
session_start();
include 'db.php';
include 'header.php';

// Hanya Admin boleh akses
if ($_SESSION['role'] != 'Admin') {
    echo "<script>alert('Akses terhad untuk Admin sahaja!'); window.location='dashboard.php';</script>";
    exit();
}
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card card-custom p-4">
                <h3 class="mb-4">Add Course</h3>
                <form action="process_course.php" method="POST">
                    <div class="mb-3">
                        <label>Course Code</label>
                        <input type="text" name="course_code" class="form-control" placeholder="Contoh: DFP40443" required>
                    </div>
                    <div class="mb-3">
                        <label>Course Name</label>
                        <input type="text" name="course_name" class="form-control" placeholder="Contoh: Full Stack Web Development" required>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" name="add" class="btn btn-success w-100">Add</button>
                        <a href="dashboard.php" class="btn btn-secondary w-100">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>