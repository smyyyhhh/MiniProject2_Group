<?php
include 'db.php';

if (isset($_POST['add'])) {
    $code = $_POST['course_code'];
    $name = $_POST['course_name'];

    $sql = "INSERT INTO courses (course_code, course_name) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $code, $name);

    if ($stmt->execute()) {
        echo "<script>alert('Kursus berjaya ditambah!'); window.location='dashboard.php';</script>";
    } else {
        echo "Ralat: " . $conn->error;
    }
}
?>